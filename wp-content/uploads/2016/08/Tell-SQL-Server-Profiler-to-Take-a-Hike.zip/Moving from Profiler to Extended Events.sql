/* 
Moving from Profiler to Extended Events 
(c) 2015 Jes Borland 
*/

/* Compare Profiler/trace Event Classes with XE Event Actions */

USE master;
GO
SELECT DISTINCT
   tb.trace_event_id AS 'Trace Event ID',
   te.name AS 'Trace Event Class',
   em.package_name AS 'XE Package',
   em.xe_event_name AS 'XE Event',
   tb.trace_column_id AS 'Trace Column ID',
   tc.name AS 'Trace Column',
   am.xe_action_name as 'XE Action'
FROM sys.trace_events te 
	LEFT OUTER JOIN sys.trace_xe_event_map em ON te.trace_event_id = em.trace_event_id 
	LEFT OUTER JOIN sys.trace_event_bindings tb ON em.trace_event_id = tb.trace_event_id 
	LEFT OUTER JOIN sys.trace_columns tc ON tb.trace_column_id = tc.trace_column_id 
	LEFT OUTER JOIN sys.trace_xe_action_map am ON tc.trace_column_id = am.trace_column_id
--ORDER BY te.name, tc.name;
ORDER BY tb.trace_event_id;

/* 
Open trace file Recompiles.sql  
Find a trace event ID 
	exec sp_trace_setevent @TraceID, 37, 9, @on
Search for it with this query 
Same for column ID 
*/
SELECT DISTINCT
   tb.trace_event_id AS 'Trace Event ID',
   te.name AS 'Trace Event Class',
   em.package_name AS 'XE Package',
   em.xe_event_name AS 'XE Event',
   tb.trace_column_id AS 'Trace Column ID',
   tc.name AS 'Trace Column',
   am.xe_action_name as 'XE Action'
FROM sys.trace_events te 
	LEFT OUTER JOIN sys.trace_xe_event_map em ON te.trace_event_id = em.trace_event_id 
	LEFT OUTER JOIN sys.trace_event_bindings tb ON em.trace_event_id = tb.trace_event_id 
	LEFT OUTER JOIN sys.trace_columns tc ON tb.trace_column_id = tc.trace_column_id 
	LEFT OUTER JOIN sys.trace_xe_action_map am ON tc.trace_column_id = am.trace_column_id
WHERE tb.trace_event_id = 37 
	AND tb.trace_column_id = 9;


/* 
Convert existing trace to XE session 

1. Execute the existing script to create a SQL Trace session, and then obtain the ID of the trace.
2. Run a query that uses the fn_trace_geteventinfo function to find the equivalent Extended Events events and actions for each SQL Trace event class and its associated columns.
3. Use the fn_trace_getfilterinfo function to list the filters and the equivalent Extended Events actions to use.
4. Manually create an Extended Events session, using the equivalent Extended Events events, actions, and predicates (filters).
*/

/* Open Recompiles.sql and execute to start trace */
/* Run query to capture trace ID  */
SELECT * 
FROM sys.traces;
GO

/* Run query to determine equivalents */
DECLARE @trace_id int; 
SET @trace_id = 3; --Equal to above trace ID 

SELECT DISTINCT el.eventid AS 'Trace Event ID', 
	em.package_name AS 'Package', 
	em.xe_event_name AS 'Event',
	el.columnid AS 'Trace Column', 
	ec.xe_action_name AS 'Action'
FROM sys.fn_trace_geteventinfo(@trace_id) AS el
	LEFT OUTER JOIN sys.trace_xe_event_map AS em ON el.eventid = em.trace_event_id
	LEFT OUTER JOIN sys.trace_xe_action_map AS ec ON el.columnid = ec.trace_column_id
WHERE em.xe_event_name IS NOT NULL 
	AND ec.xe_action_name IS NOT NULL; 


/* Copy 'event' column items here 


*/

/* Start by creating the event session STATEMENT 
 Do not execute - this isn't complete */ 
IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name='Recompiles')
   DROP EVENT SESSION Recompiles ON SERVER;
CREATE EVENT SESSION Recompiles ON SERVER 

/* Now, we add in the events 
Use that list you copied earlier, preceded by sqlserver. 
Still not ready to execute - still not complete */ 
IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name='Recompiles')
   DROP EVENT SESSION Recompiles ON SERVER;
CREATE EVENT SESSION Recompiles ON SERVER
	ADD EVENT sqlserver.sql_statement_recompile 
		(
		), 
	ADD EVENT sqlserver.cursor_recompile
		(
		), 


/* Now, we add in the actions. You'll copy these from the "equivalent" query. 
Check and double-check your commas! 
Don't run - still not complete! */
IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name='Recompiles')
   DROP EVENT SESSION Recompiles ON SERVER;
CREATE EVENT SESSION Recompiles ON SERVER 
	ADD EVENT sqlserver.sql_statement_recompile 
		(ACTION 
			(
			sqlserver.database_id,
			
			)
		), 
	ADD EVENT sqlserver.cursor_recompile
		(ACTION 
			(sqlserver.database_id,
			
			)
		) 

/* Alter the target file names here. 
Copy all of the above event/action text and add it above the target statement */
IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name='Recompiles')
   DROP EVENT SESSION Recompiles ON SERVER;
CREATE EVENT SESSION Recompiles ON SERVER 
	ADD EVENT sqlserver.sql_statement_recompile 
		(ACTION 
			(
			sqlserver.database_id,
			
			)
		), 
	ADD EVENT sqlserver.cursor_recompile
		(ACTION 
			(sqlserver.database_id,
			)
		) 
ADD TARGET package0.asynchronous_file_target
   (SET filename='D:\Trace\Recompiles.xel', max_rollover_files=(3));

/* You can finally execute this! */
/* Look at Object Explorer or run the below query to see if it exists. */
SELECT *
FROM sys.dm_xe_sessions; 

/* Minor, yet important, detail. */ 
ALTER EVENT SESSION Recompiles ON SERVER STATE = START;

/* Check again */ 
SELECT *
FROM sys.dm_xe_sessions; 

/* View live data 
But be careful! */

/* Test */ 
USE AdventureWorks2012;
GO 

SELECT * 
FROM Sales.SalesOrderDetail
WHERE SalesOrderID = 43847
OPTION (RECOMPILE); 

/* Stop session. */ 
ALTER EVENT SESSION Recompiles ON SERVER STATE = STOP;

/* Stop trace */
EXEC sp_trace_setstatus 2,0

/* Remove trace from system */
EXEC sp_trace_setstatus 2,2

/* 
Clean-up 
Delete .trc, .xel file from D:\Trace 
Drop event session 
*/