/* Level Up Your SQL Server Index Knowledge 
Jes Borland 
June 10, 2015 

These queries can be modified with attribution given. */

	/* General info - table name, index name, type, properties  */ 
	SELECT SCHEMA_NAME(OBJ.schema_id) + '.' + OBJECT_NAME(IX.object_id) AS TableName, 
		IX.name AS IndexName, 
		IX.type_desc AS TypeOfIndex, 
		CASE WHEN is_unique=1 THEN 'Yes' 
			ELSE '' END AS IsUnique, 
		CASE WHEN is_primary_key=1 THEN 'Yes' 
			ELSE '' END AS IsPrimaryKey, 
		CASE WHEN is_unique=1 THEN 'Yes'
			ELSE '' END AS IsPartOfUniqueConstraint,
		CASE WHEN has_filter=1 THEN 'Yes'
			ELSE'' END AS IsFilteredIndex 
	FROM sys.indexes IX 
		JOIN sys.objects OBJ ON OBJ.object_id = IX.object_id
	WHERE OBJ.type NOT IN('S', 'IT', 'TF') 
		AND IX.is_hypothetical=0
	ORDER BY SCHEMA_NAME(OBJ.schema_id), 
		OBJECT_NAME(IX.object_id), 
		IX.name; 



	/* More information about columns */ 
	SELECT SCHEMA_NAME(OBJ.schema_id) + '.' + OBJECT_NAME(IX.object_id) AS TableName, 
		IX.name AS IndexName, 
		IX.type_desc AS TypeOfIndex, 
		CASE WHEN is_unique=1 THEN 'Yes' 
			ELSE '' END AS IsUnique, 
		CASE WHEN is_primary_key=1 THEN 'Yes' 
			ELSE '' END AS IsPrimaryKey, 
		CASE WHEN is_unique=1 THEN 'Yes'
			ELSE '' END AS IsPartOfUniqueConstraint,
		CASE WHEN has_filter=1 THEN 'Yes'
			ELSE'' END AS IsFilteredIndex, 
		COL.name AS ColumnName, 
		TY.name AS DataType,
		COL.max_length AS ColMaxLength, 
		CASE WHEN is_descending_key=1 THEN 'DESC' 
			ELSE 'ASC' END AS ColOrder
	FROM sys.indexes IX 
		JOIN sys.index_columns IXC ON IXC.object_id = IX.object_id 
			AND IXC.index_id = IX.index_id
		JOIN sys.columns COL ON COL.object_id = IXC.object_id 
			AND COL.column_id=IXC.column_id
		JOIN sys.objects OBJ ON OBJ.object_id = IX.object_id 
		JOIN sys.types TY ON TY.user_type_id=COL.user_type_id
	WHERE OBJ.type NOT IN('S', 'IT', 'TF') 
		AND IX.is_hypothetical=0
	ORDER BY SCHEMA_NAME(OBJ.schema_id), 
		OBJECT_NAME(IX.object_id), 
		IX.name, 
		key_ordinal; 



		/* Index usage */
		SELECT DB_NAME(database_id) AS database_name, OBJECT_NAME(IUS.object_id) AS table_name, IX.name AS index_name, user_seeks, user_scans, user_lookups, user_updates, system_seeks, system_scans, system_lookups, system_updates 
		FROM sys.dm_db_index_usage_stats IUS
			INNER JOIN sys.indexes IX ON IX.index_id = IUS.index_id
				   AND IUS.object_id = IX.object_id
			INNER JOIN sys.objects OBJ ON IUS.object_id = OBJ.object_id 
			INNER JOIN sys.schemas SCH ON OBJ.schema_id = SCH.schema_id;
		
		/* With dates */
		SELECT DB_NAME(database_id) AS database_name, OBJECT_NAME(IUS.object_id) AS table_name, IX.name AS index_name, user_seeks, user_scans, user_lookups, user_updates, last_user_seek, last_user_scan, last_user_lookup, last_user_update, system_seeks, system_scans, system_lookups, system_updates, last_system_seek, last_system_scan, last_system_lookup, last_system_update 
		FROM sys.dm_db_index_usage_stats IUS
			INNER JOIN sys.indexes IX ON IX.index_id = IUS.index_id
				   AND IUS.object_id = IX.object_id
			INNER JOIN sys.objects OBJ ON IUS.object_id = OBJ.object_id 
			INNER JOIN sys.schemas SCH ON OBJ.schema_id = SCH.schema_id; 

		

		/* Missing indexes */ 
		--database, seeks, scans, avg_cost, impact 
		SELECT MID.statement AS table_name, MIGS.user_seeks, MIGS.user_scans, MIGS.avg_total_user_cost, MIGS.avg_user_impact, MID.equality_columns, MID.inequality_columns, MID.included_columns 
		FROM sys.dm_db_missing_index_groups MIG 
			INNER JOIN sys.dm_db_missing_index_group_stats MIGS ON MIGS.group_handle = MIG.index_group_handle
			INNER JOIN sys.dm_db_missing_index_details MID ON MIG.index_handle = MID.index_handle;